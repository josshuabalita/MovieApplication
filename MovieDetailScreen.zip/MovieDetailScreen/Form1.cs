﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MovieDetailScreen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            
            InitializeComponent();

            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == DialogResult.OK)
            {

                axWindowsMediaPlayer1.URL = ofd.FileName;

            }
        
        }

        private void homebutton_Click(object sender, EventArgs e)//takes you to the home page
        {

        }

        private void favoritesbutton_Click(object sender, EventArgs e)//takes you to the favorites page
        {

        }

        private void watchlistbutton_Click(object sender, EventArgs e)//tkaes you to the watchlist page
        {

        }

        private void profilebutton_Click(object sender, EventArgs e)//takes you to the profile page
        {

        }
    }
}
