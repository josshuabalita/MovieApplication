﻿namespace MovieDetailScreen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.homebutton = new System.Windows.Forms.Button();
            this.favoritesbutton = new System.Windows.Forms.Button();
            this.watchlistbutton = new System.Windows.Forms.Button();
            this.profilebutton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.score = new System.Windows.Forms.Label();
            this.description = new System.Windows.Forms.Label();
            this.addtofavorites = new System.Windows.Forms.Button();
            this.addtowatchlist = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // homebutton
            // 
            this.homebutton.Location = new System.Drawing.Point(422, 2);
            this.homebutton.Name = "homebutton";
            this.homebutton.Size = new System.Drawing.Size(88, 47);
            this.homebutton.TabIndex = 0;
            this.homebutton.Text = "Home";
            this.homebutton.UseVisualStyleBackColor = true;
            this.homebutton.Click += new System.EventHandler(this.homebutton_Click);
            // 
            // favoritesbutton
            // 
            this.favoritesbutton.Location = new System.Drawing.Point(516, 2);
            this.favoritesbutton.Name = "favoritesbutton";
            this.favoritesbutton.Size = new System.Drawing.Size(88, 47);
            this.favoritesbutton.TabIndex = 1;
            this.favoritesbutton.Text = "Favorites";
            this.favoritesbutton.UseVisualStyleBackColor = true;
            this.favoritesbutton.Click += new System.EventHandler(this.favoritesbutton_Click);
            // 
            // watchlistbutton
            // 
            this.watchlistbutton.Location = new System.Drawing.Point(610, 2);
            this.watchlistbutton.Name = "watchlistbutton";
            this.watchlistbutton.Size = new System.Drawing.Size(88, 47);
            this.watchlistbutton.TabIndex = 2;
            this.watchlistbutton.Text = "Watch List";
            this.watchlistbutton.UseVisualStyleBackColor = true;
            this.watchlistbutton.Click += new System.EventHandler(this.watchlistbutton_Click);
            // 
            // profilebutton
            // 
            this.profilebutton.Location = new System.Drawing.Point(704, 2);
            this.profilebutton.Name = "profilebutton";
            this.profilebutton.Size = new System.Drawing.Size(88, 47);
            this.profilebutton.TabIndex = 3;
            this.profilebutton.Text = "User\'s Name";
            this.profilebutton.UseVisualStyleBackColor = true;
            this.profilebutton.Click += new System.EventHandler(this.profilebutton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(431, 285);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Review Score:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(434, 329);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Description:";
            // 
            // score
            // 
            this.score.AutoSize = true;
            this.score.Location = new System.Drawing.Point(555, 285);
            this.score.Name = "score";
            this.score.Size = new System.Drawing.Size(105, 16);
            this.score.TabIndex = 6;
            this.score.Text = "score goes here";
            // 
            // description
            // 
            this.description.AutoSize = true;
            this.description.Location = new System.Drawing.Point(555, 329);
            this.description.Name = "description";
            this.description.Size = new System.Drawing.Size(129, 16);
            this.description.TabIndex = 7;
            this.description.Text = "description gos here";
            // 
            // addtofavorites
            // 
            this.addtofavorites.Location = new System.Drawing.Point(437, 382);
            this.addtofavorites.Name = "addtofavorites";
            this.addtofavorites.Size = new System.Drawing.Size(128, 35);
            this.addtofavorites.TabIndex = 8;
            this.addtofavorites.Text = "Add To favorites";
            this.addtofavorites.UseVisualStyleBackColor = true;
            // 
            // addtowatchlist
            // 
            this.addtowatchlist.Location = new System.Drawing.Point(583, 382);
            this.addtowatchlist.Name = "addtowatchlist";
            this.addtowatchlist.Size = new System.Drawing.Size(128, 35);
            this.addtowatchlist.TabIndex = 9;
            this.addtowatchlist.Text = "Add To Watch List";
            this.addtowatchlist.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(29, 68);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(276, 349);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Movie Streams";
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(354, 68);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(434, 207);
            this.axWindowsMediaPlayer1.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.addtowatchlist);
            this.Controls.Add(this.addtofavorites);
            this.Controls.Add(this.description);
            this.Controls.Add(this.score);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.profilebutton);
            this.Controls.Add(this.watchlistbutton);
            this.Controls.Add(this.favoritesbutton);
            this.Controls.Add(this.homebutton);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button homebutton;
        private System.Windows.Forms.Button favoritesbutton;
        private System.Windows.Forms.Button watchlistbutton;
        private System.Windows.Forms.Button profilebutton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label score;
        private System.Windows.Forms.Label description;
        private System.Windows.Forms.Button addtofavorites;
        private System.Windows.Forms.Button addtowatchlist;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
    }
}

